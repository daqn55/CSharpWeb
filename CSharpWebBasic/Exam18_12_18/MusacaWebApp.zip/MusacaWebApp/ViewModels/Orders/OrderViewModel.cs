﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MusacaWebApp.ViewModels.Orders
{
    public class OrderViewModel
    {
        public string Name { get; set; }

        public int Quantity { get; set; }

        public string Price { get; set; }
    }
}
