﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MusacaWebApp.ViewModels.Orders
{
    public class SimpleOrderViewModel
    {
        public long Barcode { get; set; }

        public int Quantity { get; set; }
    }
}
