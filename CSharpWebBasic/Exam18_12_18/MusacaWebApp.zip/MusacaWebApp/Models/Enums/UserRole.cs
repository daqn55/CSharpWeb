﻿namespace MusacaWebApp.Models.Enums
{
    public enum UserRole
    {
        User = 1,
        Admin = 2
    }
}