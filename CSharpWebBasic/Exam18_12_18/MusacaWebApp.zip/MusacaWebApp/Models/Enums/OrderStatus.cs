﻿namespace MusacaWebApp.Models.Enums
{
    public enum OrderStatus
    {
        Active = 1,
        Completed = 2
    }
}